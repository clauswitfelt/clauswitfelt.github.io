<?php // utf-8 Marker: äöü 

	$plugin_tx['convert_content']['headline_plugin']="Plugin convert_h1split";
	$plugin_tx['convert_content']['text_backup_hint']="Machen Sie ein Backup der gesamten Installation, bevor Sie irgendetwas tun!";
	$plugin_tx['convert_content']['text_config_changed']="Sie haben die CMS Konfiguration auf h1only_splitting umgestellt.";
	$plugin_tx['convert_content']['text_conversion_complete']="Die Konvertierung zu h1only_splitting ist komplett.";
	$plugin_tx['convert_content']['text_convert_content']="Konvertiere die Inhaltsdatei (content.php) zu ";
	$plugin_tx['convert_content']['text_h1only_splitting']="h1only_splitting";
	$plugin_tx['convert_content']['text_plugin_description']="Jetzt müssen Sie noch Ihre Inhaltsdatei (content.php) auf die alternative Seitensplitting-Methode h1only_splitting umstellen. Dabei werden alle evtl. vorhandenen Styles, Klassen und IDs der Hauptüberschriften der CMSimple Seiten entfernt.";
	$plugin_tx['convert_content']['text_usage_hint']="Verwenden Sie diese Funktionen nicht auf öffentlichen Internetseiten!";
	$plugin_tx['convert_content']['utf8_marker']="äöü";

?>
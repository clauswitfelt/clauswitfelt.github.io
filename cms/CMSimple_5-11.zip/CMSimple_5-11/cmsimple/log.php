<?php // utf-8 marker: äöü
if(!defined('CMSIMPLE_VERSION') || preg_match('/log.php/i', $_SERVER['SCRIPT_NAME'])){die('No direct access');} ?>
==============================
2023-01-31 08:26:20 from 127.0.0.1 login failed: /CMSimple5_Development/dev_511/ ##### "" ##### 
2023-01-31 08:26:07 from 127.0.0.1 login failed: /CMSimple5_Development/dev_511/ ##### "" ##### 
2023-01-31 08:17:47 from 127.0.0.1 logged_in: /CMSimple5_Development/test/ - ""
2023-01-31 08:16:52 from 127.0.0.1 login failed: /CMSimple5_Development/test/ ##### "" ##### 
